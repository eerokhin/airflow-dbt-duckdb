from pathlib import Path
import duckdb


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "warehouse" / "shop.duckdb"
DATA_DIR = ROOT / "data" / "raw"


def main():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(str(DB_PATH))
    try:
        con.execute("CREATE SCHEMA IF NOT EXISTS raw")
        for table_name in ("orders", "clients"):
            csv_path = DATA_DIR / f"{table_name}.csv"
            if not csv_path.exists():
                raise FileNotFoundError(csv_path)
            con.execute(
                f"""
                CREATE OR REPLACE TABLE raw.{table_name} AS
                SELECT *
                FROM read_csv_auto(?, header = true)
                """,
                [str(csv_path)],
            )
            count = con.execute(
                f"SELECT COUNT(*) FROM raw.{table_name}"
            ).fetchone()[0]

            print(f"Loaded raw.{table_name}: {count} rows")
    finally:
        con.close()

if __name__ == "__main__":
    main()