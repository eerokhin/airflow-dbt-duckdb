-- Singular test: должен вернуть 0 строк.
select *
from {{ ref('daily_revenue') }}
where revenue_rub < 0
