select
    cast(order_id as integer) as order_id,
    cast(client_id as integer) as client_id,
    cast(created_at as timestamp)::date as order_date,
    cast(amount_kop as decimal(14, 0)) / 100 as amount_rub,
    lower(trim(status)) as status
from {{ source('raw', 'orders') }}
where lower(trim(status)) != 'test'
