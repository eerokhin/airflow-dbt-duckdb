select
    order_date,
    count(*) as orders,
    sum(amount_rub) as revenue_rub
from {{ ref('stg_orders') }}
where status = 'paid'
group by order_date
