
{{config(materialized='incremental', unique_key='order_id')}}
select
    order_id,
    client_id,
    order_date,
    amount_rub,
    status
from {{ ref('stg_orders') }}
{% if is_incremental() %}
where order_date >= (select max(order_date) from {{ this }})
{% endif %}
