Перейти в корень проекта

создать вирт окруж
python -m venv .venv

Затем активируй его:
.\.venv\Scripts\Activate.ps1


Затем установи зависимости:
python -m pip install --upgrade pip
pip install -r requirements.txt


После установки проверь dbt:
dbt --version

Загружаем исходные данные в DuckDB
Выполни:
python scripts/load_data.py

Ожидаемый результат:
Loaded raw.orders: 8 rows
Loaded raw.clients: 4 rows


После этого в папке warehouse должен появиться файл:
shop.duckdb


Проверяем подключение
Убедись, что PowerShell находится в корне проекта:
C:\Users\erohi\Desktop\dbt-duckdb-shop

Выполни:
dbt debug



Теперь запускаем первую сборку.
Шаг 6. Первый dbt build
Выполни из корня проекта:
dbt build

dbt должен:
1. Создать представление stg_orders в схеме dev_evgen.
2. Создать таблицу daily_revenue.
3. Создать инкрементальную таблицу orders_inc.
4. Запустить проверки качества данных.



Проверим данные в DuckDB
Выполни одну команду:
python -c "import duckdb; con=duckdb.connect('warehouse/shop.duckdb'); print('RAW ORDERS:'); con.sql('SELECT COUNT(*) AS cnt FROM raw.orders').show(); print('STAGING ORDERS:'); con.sql('SELECT COUNT(*) AS cnt FROM dev_evgen.stg_orders').show(); print('DAILY REVENUE:'); con.sql('SELECT * FROM dev_evgen.daily_revenue ORDER BY order_date').show(); print('INCREMENTAL ORDERS:'); con.sql('SELECT COUNT(*) AS cnt FROM dev_evgen.orders_inc').show(); con.close()"





dbt не выполняет SQL-вычисления самостоятельно. Он формирует SQL-запросы и отправляет их на выполнение в DuckDB.
Как происходит выполнение
Допустим, у нас есть модель stg_orders.sql:
select
    order_id,
    client_id,
    amount_kop / 100 as amount_rub

from {{ source('raw', 'orders') }}


Когда мы запускаем:
dbt build


происходит следующее:
1. dbt читает SQL-файл модели.
2. Обрабатывает Jinja-конструкции, например source().
3. Компилирует SQL в обычный SQL-запрос.
4. Через адаптер dbt-duckdb отправляет запрос в DuckDB.
5. DuckDB выполняет SQL: читает данные, вычисляет выражения и создаёт результат.
6. dbt получает результат выполнения и переходит к следующим моделям и тестам.







Сейчас мы запускаем сборку вручную из PowerShell командой:
dbt build


То есть пока процесс такой:
1. Ты запускаешь команду.
2. dbt читает конфигурацию и SQL-модели.
3. dbt отправляет SQL-запросы в DuckDB.
4. DuckDB выполняет запросы.
5. dbt запускает тесты и выводит результат.
Автоматического расписания пока нет.

Позже подключим Airflow, и он будет запускать dbt build автоматически, например каждый день в 06:00.

Тогда тебе не придётся запускать сборку вручную. Airflow будет управлять всем процессом.





Сейчас у нас собралось в dev, а именно в схеме:
dev_evgen


Конфигурация prod пока существует, но мы её ещё не запускали.

Чтобы собрать модели в analytics, выполни из корня проекта:
dbt build --target prod


dbt возьмёт настройки из секции:
prod:
  type: duckdb
  path: warehouse/shop.duckdb
  schema: analytics
  threads: 1