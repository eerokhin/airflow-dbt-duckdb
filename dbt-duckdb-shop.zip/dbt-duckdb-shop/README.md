# Запуск проекта dbt-duckdb-shop

## 1. Переходим в корень проекта

Открой PowerShell и перейди в директорию проекта:

```powershell
cd C:\Users\erohi\Desktop\dbt-duckdb-shop
```

## 2. Создаём виртуальное окружение

```powershell
python -m venv .venv
```

Активируем его:

```powershell
.\.venv\Scripts\Activate.ps1
```

Устанавливаем зависимости:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Проверяем установку dbt:

```powershell
dbt --version
```

## 3. Загружаем исходные данные в DuckDB

Выполняем скрипт загрузки данных:

```powershell
python scripts/load_data.py
```

Ожидаемый результат:

```text
Loaded raw.orders: 8 rows
Loaded raw.clients: 4 rows
```

После выполнения в папке `warehouse` должен появиться файл:

```text
shop.duckdb
```

В нём будут находиться исходные таблицы `raw.orders` и `raw.clients`.

## 4. Проверяем подключение к DuckDB

Убедись, что PowerShell находится в корне проекта, и выполни:

```powershell
dbt debug
```

Команда проверит конфигурацию проекта, профиль подключения и доступность DuckDB.

## 5. Запускаем первую сборку dbt

Выполняем из корня проекта:

```powershell
dbt build
```

Во время сборки dbt:

1. Создаст представление `stg_orders` в схеме `dev_evgen`.
2. Создаст таблицу `daily_revenue`.
3. Создаст инкрементальную таблицу `orders_inc`.
4. Выполнит настроенные проверки качества данных.
5. Запустит snapshot для отслеживания изменений клиентов.

Если все этапы завершились успешно, проект собран.

## 6. Проверяем результаты в DuckDB

Выполним несколько SQL-запросов одной командой:

```powershell
python -c "import duckdb; con=duckdb.connect('warehouse/shop.duckdb'); print('RAW ORDERS:'); con.sql('SELECT COUNT(*) AS cnt FROM raw.orders').show(); print('STAGING ORDERS:'); con.sql('SELECT COUNT(*) AS cnt FROM dev_evgen.stg_orders').show(); print('DAILY REVENUE:'); con.sql('SELECT * FROM dev_evgen.daily_revenue ORDER BY order_date').show(); print('INCREMENTAL ORDERS:'); con.sql('SELECT COUNT(*) AS cnt FROM dev_evgen.orders_inc').show(); con.close()"
```

Проверяем:

- `raw.orders` — исходные заказы.
- `dev_evgen.stg_orders` — очищенные и преобразованные заказы.
- `dev_evgen.daily_revenue` — витрина ежедневной выручки.
- `dev_evgen.orders_inc` — инкрементальная таблица заказов.

## 7. Как dbt выполняет SQL

Важно понимать: **dbt не выполняет SQL-вычисления самостоятельно.** Он формирует SQL-запросы и отправляет их на выполнение в целевую базу данных — в нашем случае DuckDB.

Допустим, у нас есть модель `stg_orders.sql`:

```sql
select
    order_id,
    client_id,
    amount_kop / 100 as amount_rub
from {{ source('raw', 'orders') }}
```

Когда мы запускаем:

```powershell
dbt build
```

происходит следующее:

1. dbt читает SQL-файл модели.
2. Обрабатывает Jinja-конструкции, например `source()`.
3. Компилирует модель в обычный SQL-запрос.
4. Через адаптер `dbt-duckdb` отправляет запрос в DuckDB.
5. DuckDB выполняет SQL: читает данные, вычисляет выражения и создаёт результат.
6. dbt получает результат выполнения и переходит к следующим моделям и тестам.

Таким образом, dbt управляет процессом преобразования данных, а непосредственно SQL выполняет DuckDB.

## 8. Как сейчас запускается сборка

На текущем этапе мы запускаем сборку вручную из PowerShell:

```powershell
dbt build
```

Процесс выглядит следующим образом:

1. Мы запускаем команду.
2. dbt читает конфигурацию и SQL-модели.
3. dbt отправляет SQL-запросы в DuckDB.
4. DuckDB выполняет запросы.
5. dbt запускает тесты и выводит результаты.

**Автоматического расписания пока нет.**

Позже подключим Airflow. Он будет запускать `dbt build` автоматически, например каждый день в 06:00.

Тогда не придётся запускать сборку вручную: Airflow будет управлять процессом и отвечать за его запуск по расписанию, а dbt — за преобразование данных и проверки.

## 9. Сборка в окружение prod

Сейчас наши модели собраны в dev-окружении, а именно в схеме:

```text
dev_evgen
```

Конфигурация `prod` уже существует в `profiles.yml`, но мы её пока не использовали.

Чтобы собрать модели в схему `analytics`, выполни из корня проекта:

```powershell
dbt build --target prod
```

dbt возьмёт настройки из секции `prod` файла `profiles.yml`:

```yaml
prod:
  type: duckdb
  path: warehouse/shop.duckdb
  schema: analytics
  threads: 1
```

В результате модели будут созданы в схеме:

```text
analytics
```

Обрати внимание: `dev` и `prod` используют один и тот же файл `shop.duckdb`, но разные схемы. Это позволяет разделить результаты сборки для разных окружений.